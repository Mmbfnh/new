// نظام المساعدة
const HelpSystem = {
  sections: {
    cards: {
      title: '🎴 البطاقات التفاعلية',
      items: [
        'النقر على البطاقة: تقليب البطاقة لرؤية الكلمة باللغتين',
        'زر 🔊: نطق الكلمة باللغة المحددة',
        'زر إظهار/إخفاء الأسماء: إخفاء أو إظهار أسماء البطاقات',
        'زر عشوائي: ترتيب البطاقات بشكل عشوائي',
        'زر إعادة الترتيب: إعادة البطاقات إلى ترتيبها الأصلي'
      ]
    },
    match: {
      title: '🎯 اختبار المطابقة',
      items: [
        'الهدف: سحب الكلمات إلى الصور المناسبة',
        'المستويات: 3 مستويات مع زيادة الصعوبة',
        'المؤقت: يحسب الوقت المتبقي لكل اختبار',
        'بدء/إيقاف: التحكم في المؤقت',
        'عشوائي الكلمات: ترتيب الكلمات بشكل عشوائي',
        'إعادة: إعادة الاختبار من البداية',
        'تحقق: التحقق من الإجابات والحصول على النجوم'
      ]
    },
    letters: {
      title: '🔤 اختبار الحروف',
      items: [
        'الهدف: تكوين الكلمة الصحيحة من الحروف المتاحة',
        'السحب والإفلات: سحب الحروف إلى المواضع المناسبة',
        'النقر على الحرف: إزالته من الموضع وإعادته إلى البنك',
        'كلمة عشوائية: اختيار كلمة جديدة عشوائياً',
        'إعادة: إعادة ترتيب الحروف في البنك',
        'تحقق: التحقق من صحة الكلمة المكونة'
      ]
    },
    admin: {
      title: '⚙️ لوحة التحكم',
      items: [
        'تسجيل الدخول: اسم المستخدم admin وكلمة المرور 1234',
        'إضافة عنصر: إضافة بطاقة جديدة مع صورة',
        'تعديل/حذف: التعديل على البطاقات الموجوعة أو حذفها',
        'تصدير/استيراد: حفظ أو استعادة البطاقات كملف JSON',
        'إعدادات الصوت: تشغيل أو إيقاف الأصوات',
        'تغيير كلمة المرور: تحديث كلمة مرور لوحة التحكم',
        'الإحصائيات: عرض إحصائيات الاستخدام'
      ]
    }
  },
  
  showSection: function(sectionName) {
    const section = this.sections[sectionName];
    if (!section) return '';
    
    let html = `<div class="help-section">
      <h3>${section.title}</h3>`;
    
    section.items.forEach(item => {
      html += `<div class="help-item">${item}</div>`;
    });
    
    html += '</div>';
    return html;
  },
  
  showAll: function() {
    let html = '';
    Object.keys(this.sections).forEach(section => {
      html += this.showSection(section);
    });
    return html;
  }
};

// دوال مساعدة للاستخدام السهل
function showHelpContent(section = 'all') {
  if (section === 'all') {
    return HelpSystem.showAll();
  }
  return HelpSystem.showSection(section);
}

function getHelpSections() {
  return Object.keys(HelpSystem.sections);
}
